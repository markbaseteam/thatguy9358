## Enumeration
### Manual
- User
	- CMD line[[Active Directory#Manual Enumeration]]
	- Powershell [[Active Directory#Enum with PowerView]]
		- `Get-DomainUsers`
		- `Get DomainShares`
- groups
### Automated
