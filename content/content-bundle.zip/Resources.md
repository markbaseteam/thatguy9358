https://github.com/darkoperator/powershell_scripts/blob/master/ps_encoder.py --> Encodes a given Windows PowerShell script in to a Base64 String that can be passed to the powershell.exe program as an option. Good for making one liners for powershell

https://powersploit.readthedocs.io/en/latest/Recon/ --> contains functions for enumerating AD

